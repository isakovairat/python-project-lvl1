import brain_games.cli
import random


def get_operation():
    operations = ["+", "-", "*"]
    index = random.randint(0, 2)
    return operations[index]


def get_correct_answer(numb1, numb2, operation):
    if operation == "*":
        return numb1 * numb2
    elif operation == "+":
        return numb1 + numb2
    elif operation == "-":
        return numb1 - numb2


def calc(name):
    count_correct = 0
    while count_correct != 3:
        number1 = random.randint(0, 100)
        number2 = random.randint(0, 100)
        operation = get_operation()
        print("Question: {} {} {}".format(number1, operation, number2))
        answer = int(input("Your answer: "))
        correct_answer = get_correct_answer(number1, number2, operation)
        if correct_answer == answer:
            count_correct += 1
            brain_games.cli.congrats(name)
        else:
            print("\'{}\' is wrong answer ;(. Correct answer was \'{}\'.".format(answer, correct_answer))
            brain_games.cli.try_again(name)


def main():
    print("Welcome to the Brain Games")
    print("What is the result of the expression?\n")
    name = brain_games.cli.run()
    calc(name)


if __name__ == '__main__':
    main()
