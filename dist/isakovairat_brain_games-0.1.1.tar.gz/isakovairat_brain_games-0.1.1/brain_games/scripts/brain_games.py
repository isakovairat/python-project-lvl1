import brain_games.cli


def main():
    brain_games.cli.run()


if __name__ == '__main__':
    main()
